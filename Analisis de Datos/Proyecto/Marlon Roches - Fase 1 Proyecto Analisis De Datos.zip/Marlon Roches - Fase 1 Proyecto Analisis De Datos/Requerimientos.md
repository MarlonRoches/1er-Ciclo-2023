# Proyecto 1 Requerimientos
- ***Diseño	Dimensional***:	detallado	y	explicado de	manera	adecuada,	recuerde	
este	 es	 su	 blue	 print,	 los	 planos	 sobre	 los	 cuales	 construirá su	 cubo	 de	
información.
    - Se encuentra detallado en el PDF de entrega
- ***Diseño	Entidad	Relación***:	El	diseño	a	nivel	de	la	base	de	datos	indicando	
los	campos	y	llaves	creadas.	 Incluir	también el	DML	de	la	creación de	las	
tablas.
    - Se encuentra detallado en el PDF de entrega

- ***Flujos	de	Tableau	Prep***:	Archivo	conteniendo	el diseño	del	flujo	de	ETL y	
como	se	efectúan las	cargas	de	las	tablas	dimensionales	y	de	hechos.
- ***Manual	Técnico***:	Explicando	el	proceso	de	carga	y	las	operaciones	sobre
efectuadas	a	los	datos,	así como	todo	lo	asumido	al	momento	de	efectuar	
este	proceso.
    - Inculir desiciones de 

